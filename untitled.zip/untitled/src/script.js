// Add event listener to the button
document.querySelector('button').addEventListener('click', (e) => {
    e.preventDefault();
    alert('Message sent!');
});